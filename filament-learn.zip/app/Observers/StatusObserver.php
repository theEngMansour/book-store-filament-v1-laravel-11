<?php

namespace App\Observers;

use NunoMaduro\Collision\Adapters\Phpunit\State;
use App\Models\Status;
use Filament\Notifications\Notification;

class StatusObserver
{
    public function created(Status $status): void
    {

        Notification::make()
            ->title('Saved successfully')
            ->sendToDatabase(auth()->user()->id);
    }
}

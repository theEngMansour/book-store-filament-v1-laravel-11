<?php

namespace App\Livewire;

use App\Models\Post;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Illuminate\Contracts\View\View;
use Livewire\Component;

class CreatePost extends Component implements HasForms
{
    use InteractsWithForms;

    public ?array $data = [];
    public ?array $postData = [];
    public ?array $commentData = [];


    protected function getForms(): array
    {
        return [
            'editPostForm',
            'createCommentForm',
        ];
    }


    public function editPostForm(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('title')
,
                MarkdownEditor::make('content'),
                // ...
            ])
            ->statePath('postData')
    ;
    }

    public function createCommentForm(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
,
                TextInput::make('email')
                    ->email()
,
                MarkdownEditor::make('content')
,
                // ...
            ])
            ->statePath('commentData');
    }



    public function createComment(): void
    {
        dd($this->createCommentForm->getState());
    }
    
    public function render(): View
    {
        return view('livewire.create-post');
    }
}

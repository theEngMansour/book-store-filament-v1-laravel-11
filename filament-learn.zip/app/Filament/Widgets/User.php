<?php

namespace App\Filament\Widgets;

use Filament\Widgets\Widget;

class User extends Widget
{
    protected static string $view = 'filament.widgets.user';
}

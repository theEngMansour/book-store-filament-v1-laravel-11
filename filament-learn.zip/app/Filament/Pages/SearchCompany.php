<?php

namespace App\Filament\Pages;

use App\Models\Product;
use Filament\Forms\Components\Group;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Pages\Page;
use Filament\Forms\Components\Button;
use Illuminate\Contracts\Support\Htmlable;
// use App\Filament\Widgets\FilamentInfoWidget;
use Filament\Tables;

use Filament\Actions\Action;


use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Illuminate\Contracts\View\View;

class SearchCompany extends Page implements HasForms, HasTable
{
    use InteractsWithTable;
    use InteractsWithForms;

    protected static ?string $navigationIcon = 'heroicon-o-document-text';

    protected static string $view = 'filament.pages.search-company';

    protected static ?string $navigationGroup = 'مبيعات';

    protected static ?string $navigationLabel = 'منتجات';

    protected static int $globalSearchResultsLimit = 2;

    protected static ?string $title = 'Custom Page Title';
    // protected static bool $shouldRegisterNavigation = false;

    public $name = '';

    public $results = [];

    // public function getTitle(): string | Htmlable
    // {
    //     return __('البحث والتحري عن الشركة');
    // }

    public function mount()
    {
        $this->form->fill([
            'name' => '',
        ]);
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('edit')
                ->url('/'),
            Action::make('delete')
                ->color('si')
                ->label('عرض')
                ->modalFooterActionsAlignment('left')
                ->requiresConfirmation()
                ->modalHeading('s')
                ->modalSubmitActionLabel('حذف الان')
                ->modalIcon('heroicon-o-document-text')
                ->modalDescription('هل تريد حقاً الحذف')
                ->action(fn () => $this->post->delete()),
            Action::make('approve')
                ->action(function (Product $record) {
                    $record->approve();

                    $this->refreshFormData([
                        'name',
                    ]);
                })
        ];
    }


    public function table(Table $table): Table
    {
        return $table
            ->query(Product::query()->where('name', 'LIKE', '%' . $this->name . '%'))
            ->columns([
                TextColumn::make('name')->searchable(),
            ])
            ->filters([
                // ...
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('a'),

            ])
            ->bulkActions([
                // ...
            ]);
    }

    protected function getFormSchema(): array
    {
        return [
            Group::make()
                ->schema([
                    Section::make('البحث عن شركة')
                        ->schema([
                            TextInput::make('name')
                                ->live()
                                ->label('اسم السجل التجاري')
                                ->placeholder('ُيرجى إدخال اسم السجل التجاري')
                                ->required(),
                        ])->columns(2),
                ])->columnSpanFull(),
        ];
    }

    // protected function getHeaderWidgets(): array
    // {
    //     return [
    //         FilamentInfoWidget::class,
    //     ];
    // }

    public static function getNavigationLabel(): string
    {
        return static::$navigationLabel = 's';
    }



    public function search()
    {
        $this->results = Product::all();

        return view('filament.pages.search-company', [
            'results' =>  $this->results,
        ]);
    }
}

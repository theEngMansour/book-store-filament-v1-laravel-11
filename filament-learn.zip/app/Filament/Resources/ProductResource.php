<?php

namespace App\Filament\Resources;

use Filament\Tables\Actions\Action;

use App\Enums\ProductTypeEnum;
use App\Filament\Resources\BrandResource\RelationManagers\ProductsRelationManager;
use App\Filament\Resources\ProductResource\Pages;
use App\Filament\Resources\ProductResource\RelationManagers;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Components\{
    DatePicker,
    FileUpload,
    Grid,
    Group,
    MarkdownEditor,
    Section,
    Select,
    TextInput,
    Toggle
};
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use pxlrbt\FilamentExcel\Actions\Tables\ExportBulkAction;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;

    protected static ?string $modelLabel = 'منتج';

    protected static ?string $inverseRelationship = 'brand'; // Since the inverse related model is `Category`, this is normally `category`, not `section`.



    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    protected static ?string $navigationGroup = 'مبيعات';

    protected static ?string $navigationLabel = 'منتجات';

    protected static int $globalSearchResultsLimit = 2;

    protected static bool $shouldRegisterNavigation = false;

    // protected static ?string $breadcrumb = null;

    // protected static ?string $recordTitleAttribute = 'name';

    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::count();
    }

    public static function getNavigationBadgeColor(): string | array | null
    {
        return static::getModel()::where('is_visible', '=', '1')->count() > 1 ? 'primary' : 'primary';
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['name', 'slug'];
    }

    public static function getGlobalSearchResultDetails(Model $record): array
    {
        return [
            'اسم منتج' => $record->name,
            'العلامة التجارية' => $record->brand->name
        ];
    }

    public static function getGlobalSearchEloquentQuery(): Builder
    {
        return parent::getGlobalSearchEloquentQuery()->with('brand');
    }

    public static function getPluralModelLabel(): string
    {
        $label = static::$modelLabel;
        $locale = app()->getLocale();
        return $label;

        /*       
            if ($locale === 'ar') {
                return $label . 's';
            } elseif ($locale === 'ar') {
                return $label;
            } else {
                return $label . 's';
            }
        */
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                // Group::make()
                //     ->schema([
                //         Section::make('البحث عن شركة')
                //             ->schema([
                //                 TextInput::make('name')->label('اسم السجل التجاري')
                //                     ->placeholder('ُيرجى إدخال اسم السجل التجاري')
                //                 // I::make('name')->label('اسم السجل التجاري')
                //             ])->columns(2)
                //     ])->columnSpanFull(),
                Group::make()
                    ->schema([
                        Section::make('بيانات المنتج')
                            ->schema([
                                TextInput::make('name')->label('الاسم')
                                    ->placeholder('يرجى إدخال الاسم')
                                    ->required()
                                    ->live(onBlur: true)
                                    // ->validationMessages('مطلوب')
                                    /*    ->afterStateUpdated(function (string $operation, $state, Set $set) {
                                        if ($operation !== 'create') return;
                                        $set('slug', \Str::slug($state));
                                    }) */
                                    ->afterStateUpdated(function (Get $get, Set $set, ?string $old, ?string $state) {
                                        if (($get('slug') ?? '') !== \Str::slug($old)) {
                                            return;
                                        }

                                        $set('slug', \Str::slug($state));
                                    }),

                                TextInput::make('slug')
                                    ->label('الاسم اللطيف')
                                    // ->disabled()
                                    ->dehydrated()
                                    ->required(),

                                MarkdownEditor::make('description')->label('الوصف')->columnSpanFull(),
                            ])->columns(2),

                        Section::make('السعر')
                            ->schema([
                                TextInput::make('sku'),
                                TextInput::make('price')->label('السعر')
                                    ->numeric()
                                    ->rules('regex:/^\d{1,6}(\.\d{0,2})?$/'),
                                TextInput::make('quantity')->label('الكمية')
                                    ->numeric()
                                    ->minValue(0)
                                    ->maxValue(100),
                                Select::make('type')->options([
                                    'downloadable' => ProductTypeEnum::DOWNLOADABLE->value,
                                    'deliverable' => ProductTypeEnum::DELIVERABLE->value,
                                ])


                            ])->columns(2),

                        /* Select::make('types')
                            ->options([
                                'employee' => 'Employee',
                                'freelancer' => 'Freelancer',
                            ])
                            ->live()
                            ->afterStateUpdated(fn (Select $component) => $component
                                ->getContainer()
                                ->getComponent('dynamicTypeFields')
                                ->getChildComponentContainer()
                                ->fill()),

                        Grid::make(2)
                            ->schema(fn (Get $get): array => match ($get('types')) {
                                'employee' => [
                                    TextInput::make('employee_number')
                                        ->required(),
                                    FileUpload::make('badge')

                                        ->required(),
                                ],
                                'freelancer' => [
                                    TextInput::make('hourly_rate')
                                        ->numeric()
                                        ->required()
                                        ->prefix('€'),
                                    FileUpload::make('contract')
                                        ->required(),
                                ],
                                default => [],
                            })
                            ->key('dynamicTypeFields') */
                    ]),
                Group::make()
                    ->schema([
                        Section::make('الحالة')
                            ->schema([
                                Toggle::make('is_visible')
                                    ->helperText('إضافة منتج ..')
                                    ->label('مرئي'),
                                Toggle::make('is_featured')->label('واردة'),
                                DatePicker::make('published_at')->label('تاريخ النشر')
                                    ->default(now())
                            ]),
                        Section::make('الصورة')
                            ->schema([
                                FileUpload::make('image')->label('رفع الملف')
                                    ->directory('images')
                                    ->preserveFilenames()
                                    ->multiple(true)
                                // ->image()
                                // ->imageEditor(),
                            ])->collapsible(),
                        Section::make('العلامة')
                            ->schema([
                                Select::make('brand_id')
                                    ->relationship('brand', 'name')
                                    ->searchable()
                                    ->live()
                                    ->afterStateUpdated(function (Get $get, Set $set, ?string $old, ?string $state) {

                                        $set('name_brand', $get('name'));
                                    }),
                            ]),
                        // Select::make('categories')
                        //     ->relationship('categories', 'name')
                        //     // ->searchable()
                        //     ->multiple(true)
                    ])
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
        
            ->columns([
                ImageColumn::make('image')->label('الصورة'),
                TextColumn::make('name')
                    ->searchable()
                    ->sortable()
                    ->label('الاسم'),
                TextColumn::make('brand.name')->label('العلامة التجارية'),
                IconColumn::make('is_visible')->boolean()->label('مرئي'),
                TextColumn::make('price')->label('السعر'),
                TextColumn::make('quantity')->label('الكمية'),
                TextColumn::make('published_at')->label('وقت النشر'),
                TextColumn::make('type')->label('النوع')->toggleable(),

            ])
            ->filters([
                TernaryFilter::make('is_visible')
                    ->label('visible')
                    ->boolean()
                    ->trueLabel('الشركات النشطة')
                    ->falseLabel('الشركات الغير نشطة'),
                SelectFilter::make('brand')
                    ->relationship('brand', 'name')
            ])
            ->actions([
                ActionGroup::make([

                    Tables\Actions\EditAction::make(),
                    ViewAction::make(),
                    Action::make('edit')
                        ->label('Edit post')
                        ->icon('heroicon-o-rectangle-stack')
                        ->url(fn (Product $record): string => "/admin/products/{$record->id}/edit/contact")
                ])

            ])
            ->bulkActions([
                ExportBulkAction::make(),
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            ProductsRelationManager::class
        ];
    }

    public static function editForm(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('title')
                    ->required(),
                Forms\Components\TextInput::make('content')
                    ->required(),
                Forms\Components\TextInput::make('additional_field')
                    ->label('Additional Field')
                    ->required(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit' => Pages\EditProduct::route('/{record}/edit'),
            'edit-contact' => Pages\EditCustomerContact::route('/{record}/edit/contact'),

        ];
    }
}

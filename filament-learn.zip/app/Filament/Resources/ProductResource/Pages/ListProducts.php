<?php

namespace App\Filament\Resources\ProductResource\Pages;

use App\Filament\Resources\ProductResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use Filament\Resources\Components\Tab;
use Illuminate\Database\Eloquent\Builder;

class ListProducts extends ListRecords
{
    protected static string $resource = ProductResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
    public function getTabs(): array
    {
        /*         return  [
            'all' => Tab::make('All')->badge($this->getModel()::count()), 
            'get' => Tab::make('All')->modifyQueryUsing(function (Builder $query) {
                return $query->whereName('w');
            }), 
            
    ]; */

        return [
            'all' => Tab::make('All customers'),
            'active' => Tab::make('Active customers')
                ->modifyQueryUsing(fn (Builder $query) => $query->where('id', 2)),
            'inactive' => Tab::make('Inactive customers')
                ->modifyQueryUsing(fn (Builder $query) => $query->where('id', 1)),
        ];
    }
}

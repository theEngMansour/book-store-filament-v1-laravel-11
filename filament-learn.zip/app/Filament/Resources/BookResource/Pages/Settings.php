<?php

namespace App\Filament\Resources\BookResource\Pages;

use App\Filament\Resources\BookResource;
use Filament\Forms\Components\Group;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Contracts\HasForms;
use Filament\Resources\Pages\Page;

class Settings extends Page implements HasForms
{
    protected static string $resource = BookResource::class;

    protected static string $view = 'filament.resources.book-resource.pages.settings';

    protected function getFormSchema(): array
    {
        return [
            Group::make()
                ->schema([
                    Section::make('البحث عن شركة')
                        ->schema([
                            TextInput::make('name')
                                ->live()
                                ->label('اسم السجل التجاري')
                                ->placeholder('ُيرجى إدخال اسم السجل التجاري')
                                ->required(),
                        ])->columns(2),
                ])->columnSpanFull(),
        ];
    }
}

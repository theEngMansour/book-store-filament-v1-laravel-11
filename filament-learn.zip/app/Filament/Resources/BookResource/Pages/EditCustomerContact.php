<?php

namespace App\Filament\Resources\BookResource\Pages;

use App\Enums\ProductTypeEnum;
use App\Filament\Resources\BookResource;
use Filament\Actions;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Pages\EditRecord;
use Filament\Forms\Form;

class EditCustomerContact extends EditRecord
{
    protected static string $resource = BookResource::class;

    protected static string $view = 'welcome';


    protected function getHeaderActions(): array
    {
        return [
            $this->getSaveFormAction()
                ->formId('form'),
        ];
    }
    
    public function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->required()
                    ->string()
                    ->live(onBlur: true)

                    ->validationMessages([
                        'required' => 'The :attribute has already been registered.',
                    ]),
                TagsInput::make('slug')
                    ->separator(','),
                Repeater::make('users')->label('مستخدمين')
                    ->schema([
                        TextInput::make('users')->required(),
                    ])
                    ->columns(2),
                MarkdownEditor::make('description'),
                FileUpload::make('image'),
                FileUpload::make('image'),
                FileUpload::make('image'),
                FileUpload::make('image'),
                FileUpload::make('image'),
                FileUpload::make('image'),
                FileUpload::make('image'),
                FileUpload::make('image'),
                TextInput::make('price')->numeric(),
                TextInput::make('quantity')->numeric(),
                Select::make('type')->options([
                    'downloadable' => ProductTypeEnum::DOWNLOADABLE->value,
                    'deliverable' => ProductTypeEnum::DELIVERABLE->value,
                ]),
                Toggle::make('is_visible'),
                Toggle::make('is_featured'),
                DatePicker::make('published_at'),


            ]);
    }
}

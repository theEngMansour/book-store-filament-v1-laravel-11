<?php

namespace App\Filament\Resources;

use Filament\Infolists\Components\Grid;
use Illuminate\Database\Eloquent\Collection;

use Filament\Forms\Components\Actions\Action;
use Filament\Infolists\Components\Section;
use Filament\Infolists\Components\TextEntry;
use Illuminate\Support\HtmlString;
use App\Enums\ProductTypeEnum;
use App\Filament\Resources\BookResource\Pages;
use App\Filament\Resources\BookResource\RelationManagers;
use App\Filament\Widgets\Product;
use App\Models\Book;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Infolists\Components\IconEntry;
use Filament\Infolists\Components\ImageEntry;
use Filament\Infolists\Components\KeyValueEntry;
use Filament\Infolists\Components\RepeatableEntry;
use Filament\Infolists\Infolist;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Actions\BulkAction;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class BookResource extends Resource
{
    protected static ?string $model = Book::class;
    protected static ?string $slug = 'bookings';

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    // public static function shouldRegisterNavigation(): bool
    // {
    //     if(auth()->user()->can('books')) {
    //         return true;
    //     }
    //     return false;
    // }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->required()
                    ->string()
                    ->live(onBlur: true)

                    ->validationMessages([
                        'required' => 'The :attribute has already been registered.',
                    ]),
                TagsInput::make('slug')
                    ->separator(','),
                Repeater::make('users')
                    ->schema([
                        TextInput::make('users')->required(),
                    ])
                    ->columns(2),
                MarkdownEditor::make('description'),
                FileUpload::make('image')->multiple(),
                TextInput::make('price')->numeric(),
                TextInput::make('quantity')->numeric(),
                Select::make('type')->options([
                    'downloadable' => ProductTypeEnum::DOWNLOADABLE->value,
                    'deliverable' => ProductTypeEnum::DELIVERABLE->value,
                ]),
                Toggle::make('is_visible'),
                Toggle::make('is_featured'),
                DatePicker::make('published_at'),


            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                //
            ])
            ->filters([
                //
            ])
            ->actions([
                // Tables\Actions\Action::make()->url(fn (Book $record): string => '/settings'),
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    BulkAction::make('show')
                        ->requiresConfirmation()
                        ->action(fn (Collection $records) => redirect('/' . $record->id)),
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }


    public static function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            // ->state([
            //     'sl' => 'MacBook Pro',
            //     'category' => [
            //         'name' => 'Laptops',
            //     ],
            // ])

            ->schema([
                Grid::make([
                    'default' => 1,
                    'sm' => 1,
                    'md' => 1,
                    'lg' => 2,
                    'xl' => 1,
                    '2xl' => 1,
                ])->schema([
                    Section::make('Rate limiting')
                        ->description('Prevent abuse by limiting the number of requests per period')
                        ->aside()
                        ->schema([
                            // ...
                        ]),
                    Section::make('Cart')
                        ->description('The items you have selected for purchase')
                        ->schema([
                            // ...
                        ])
                        ->collapsed(),
                    Section::make('Cart')
                        ->description('The items you have selected for purchase')
                        ->icon('heroicon-m-shopping-bag')
                        ->schema([
                            TextEntry::make('name'),
                            TextEntry::make('slug'),
                        ])->columnSpanFull(2),
                    IconEntry::make('is_featured')
                        ->boolean()
                        ->boolean()
                        ->trueIcon('heroicon-o-check-badge')
                        ->falseIcon('heroicon-o-x-mark'),
                    ImageEntry::make('image')->height(40)
                        ->circular()->stacked()->limit(3),


                    TextEntry::make('sl')->helperText('Your full name here, including any middle names.')->columnSpanFull(),
                    TextEntry::make('category.name')->placeholder('Untitled'),
                    TextEntry::make('name')->label('Post title'),
                    TextEntry::make('url')
                        ->url('/s'),
                    TextEntry::make('content')
                        ->columnSpan(2)
                        ->markdown(),
                    Section::make('Media')
                        ->description('Images used in the page layout.')
                        ->schema([
                            TextEntry::make('slug')
                        ]),
                    TextEntry::make('name')
                        ->helperText(new HtmlString('Your <strong>full name</strong> here, including any middle names.')),

                    TextEntry::make('name')
                        ->helperText(str('Your **full name** here, including any middle names.')->inlineMarkdown()->toHtmlString()),

                    TextEntry::make('apiKey')
                        ->label('API key')
                        ->hint(new HtmlString('<a href="/documentation">Documentation</a>')),
                    TextEntry::make('name')
                        ->label('API key')
                        ->hint(str('[Documentation](/documentation)')->inlineMarkdown()->toHtmlString())
                        ->hintColor('primary')
                        ->tooltip('Shown at the top of the page')
                        ->hintIcon('heroicon-m-question-mark-circle'),
                    TextEntry::make('amount_including_vat')
                        ->state(function (Book $record): float {
                            return $record->id + 1;
                        }),
                    TextEntry::make('title')
                        ->tooltip(fn (Book $record): string => "By {$record->slug}"),

                    TextEntry::make('slug')
                        ->extraAttributes(['class' => 'bg-gray-200']),
                    TextEntry::make('test')->color(fn ($state): string => match ($state) {
                        's' => 's'
                    }),
                    TextEntry::make('name')
                        ->label('API key')
                        ->copyable()
                        ->copyMessage('Copied!')
                        ->copyMessageDuration(1500),
                    TextEntry::make('price')
                        ->money(''),
                    TextEntry::make('slug')
                        ->badge()
                        ->separator(',')
                ])

            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListBooks::route('/'),
            'create' => Pages\CreateBook::route('/create'),
            'edit' => Pages\EditBook::route('/{record}/edit'),
            'edit-contact' => Pages\EditCustomerContact::route('/{record}/edit/contact'),
            'settings' => Pages\Settings::route('/settings'),
            'view' => Pages\ViewBook::route('/{record}'),

        ];
    }
}

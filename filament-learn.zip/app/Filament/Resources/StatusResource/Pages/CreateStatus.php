<?php

namespace App\Filament\Resources\StatusResource\Pages;

use App\Filament\Resources\StatusResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;
use Filament\Notifications\Actions\Action;
use Filament\Notifications\Notification;
use Filament\Notifications\Events\DatabaseNotificationsSent;

class CreateStatus extends CreateRecord
{
    protected static string $resource = StatusResource::class;
    
    protected function afterCreate(): void
    {
        $order = $this->record;
        $user = auth()->user();
        Notification::make()
            ->title('New order')
            ->icon('heroicon-o-shopping-bag')
            ->body("**s**")
            ->sendToDatabase($user);
    }
}

<?php

namespace App\Filament\Resources\BrandResource\Pages;

use App\Filament\Resources\BrandResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use Filament\Resources\Components\Tab;

class ListBrands extends ListRecords
{
    protected static string $resource = BrandResource::class;
    protected static ?string $navigationLabel = 'منتجات';
    protected static ?string $modelLabel = 'منتج';

    public function getTabs(): array
    {
        return [
            'all' => Tab::make('All customers'),
            'active' => Tab::make('Active customers')
                ->modifyQueryUsing(fn (Builder $query) => $query->where('is_visible', 1)),
            'inactive' => Tab::make('Inactive customers')
                ->modifyQueryUsing(fn (Builder $query) => $query->where('is_visible', 1)),
        ];
    }

    protected function getHeaderActions(): array
    {
        return [
            // Actions\CreateAction::make(),
        ];
    }
}

<?php

namespace App\Filament\Resources\BrandResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Tabs;
use Filament\Forms\Components\Tabs\Tab;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class ProductsRelationManager extends RelationManager
{

    protected static string $relationship = 'products';

    protected static ?string $modelLabel = 'منتج';
    protected static ?string $navigationLabel = 'منتجات';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Tabs::make('producs')
                    ->tabs([
                        Tab::make('information')
                            ->schema([
                                TextInput::make('name')->label('الاسم')
                                    ->placeholder('يرجى إدخال الاسم')
                                    ->required()
                                    ->live(onBlur: true)
                                    // ->validationMessages('مطلوب')
                                    /*    ->afterStateUpdated(function (string $operation, $state, Set $set) {
                                            if ($operation !== 'create') return;
                                            $set('slug', \Str::slug($state));
                                        }) */
                                    ->afterStateUpdated(function (Get $get, Set $set, ?string $old, ?string $state) {
                                        if (($get('slug') ?? '') !== \Str::slug($old)) {
                                            return;
                                        }

                                        $set('slug', \Str::slug($state));
                                    }),

                                TextInput::make('slug')
                                    ->label('الاسم اللطيف')
                                    // ->disabled()
                                    ->dehydrated()
                                    ->required(),

                                MarkdownEditor::make('description')->label('الوصف')->columnSpanFull(),
                            ])->columns(2),
                        Tab::make('price')
                            ->schema([]),
                        Tab::make('inormations')
                            ->schema([])
                    ])->columnSpanFull()
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('name')
            ->columns([
                Tables\Columns\TextColumn::make('name'),
            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}

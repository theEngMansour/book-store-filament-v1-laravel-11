<?php

namespace App\Providers\Filament;
use Rupadana\ApiService\ApiServicePlugin;
use pxlrbt\FilamentSpotlight\SpotlightPlugin;
use Althinect\FilamentSpatieRolesPermissions\FilamentSpatieRolesPermissionsPlugin;

use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Pages;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\Widgets;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\AuthenticateSession;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;
use Filament\FontProviders\LocalFontProvider;
use Filament\Navigation\MenuItem;
use Filament\Navigation\NavigationItem;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel

            ->navigationGroups([
                'admin'
            ])
            ->default()
            ->id('admin')
            ->path('admin')
            ->login()
            ->colors([
                'primary' => '#0085ff',
                'si' => '#000fff'
            ])
            ->navigationItems([
                NavigationItem::make('search')
                    ->url('/admin/products', shouldOpenInNewTab: false)
                    ->icon('heroicon-o-rectangle-stack')
                    ->group('مبيعات')
                    ->sort(2)
                    // ->hidden(auth()->user()->can('show-book'))
                    ->visible(fn (): bool => auth()->user()->can('show-book'))
                // ->isActiveWhen()

            ])
            // ->breadcrumbs(false)
            ->userMenuItems([
                MenuItem::make()
                    ->label('settings')
                    ->url('/admin/products', shouldOpenInNewTab: false)
                    ->icon('heroicon-o-rectangle-stack'),
                'logout' => MenuItem::make()->label('lo')
            ])
            ->sidebarCollapsibleOnDesktop(true)
            // ->sidebarFullyCollapsibleOnDesktop(true)
            ->darkMode()
            ->plugins([
                FilamentSpatieRolesPermissionsPlugin::make(),
                SpotlightPlugin::make(),
                ApiServicePlugin::make()
            ])
            ->font(
                'Tajawal',
                url: asset('/css/fonts.css'),
                provider: LocalFontProvider::class,
            )
            ->brandLogo(fn () => view('logo'))
            ->brandLogoHeight('3rem')
            ->favicon(asset('/system.svg'))
            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\\Filament\\Resources')
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\\Filament\\Pages')
            ->pages([
                Pages\Dashboard::class,
            ])
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\\Filament\\Widgets')
            ->widgets([
                Widgets\AccountWidget::class,
                Widgets\FilamentInfoWidget::class,
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ])
            ->databaseNotifications();
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    use HasFactory;

    protected $guarded = [];

    public static array $allowedFields = [
        'name'
    ];
    protected $casts = [
        'name' => 'array',
    ];
    // Which fields can be used to sort the results through the query string
    // public static array $allowedSorts = [
    //     'id',
    //     'created_at'
    // ];
 
    // Which fields can be used to filter the results through the query string
    public static array $allowedFilters = [
        'name'
    ];

}

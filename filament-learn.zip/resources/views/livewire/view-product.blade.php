<div>
    {{ $this->productInfolist }}
</div>

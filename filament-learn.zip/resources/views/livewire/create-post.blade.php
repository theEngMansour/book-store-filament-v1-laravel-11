<div>
    <form wire:submit="createComment">
        {{ $this->createCommentForm }}
        
        <button type="submit">
            Submit
        </button>
    </form>
    
    <x-filament-actions::modals />
</div>
<div>
    <form wire:submit="create">
        {{ $this->form }}
        
        <button wire:click="create">
            Submit
        </button>
    </form>
    
</div>
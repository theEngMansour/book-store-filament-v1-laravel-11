<x-filament-panels::page>

    <form wire:submit.prevent="search">
        {{ $this->form }}

        <div style="margin: 12px;" class="mt-4">
            @livewire(\App\Livewire\BlogPostsChart::class)
            <x-filament::button type="submit">بحث</x-filament::button>
        </div>
    </form>

    @if ( count($results) > 0)
        <div class="mt-4">
            {{ $this->table }}
            <h2>نتائج البحث</h2>
        </div>
    @endif

    <x-filament::fieldset>
    <x-slot name="label">
        Address
    </x-slot>
    <div>
      
    </div>
    {{-- Form fields --}}
</x-filament::fieldset>
</x-filament-panels::page>

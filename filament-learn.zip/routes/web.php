<?php
use App\Livewire\ViewProduct;
use App\Livewire\CreatePost;

use Illuminate\Support\Facades\Route;
Route::get('posts/create', CreatePost::class);


Route::get('/', function () {
    return view('welcome');
})->name('welcome');

 
Route::get('products/{product}', ViewProduct::class);




Route::get('/admin/settings', function ($id) {
    return redirect('/products/'.$id.'/edit/contact');
})->name('settings');


